/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecoscore;

// imports classes necessary to work with arrays and lists
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author emilychappel
 */

public class RecommendationGenerator {
    // custom method to generate personalized recommendations with eco-friendly tips
    public List<String> generateRecommendations(Users user) {
        // creates a List to store the personalized recommendations
        List<String> recommendations = new ArrayList<>();

        // calculates user’s ecological footprint score using the getCO2Eq method
        double userFootprintScore = user.getCO2Eq();

        // determines personalized recommendations based on user's ecological footprint measured in CO2 emissions in tons
        if (userFootprintScore > 25){
            recommendations.add("Your ecological footprint is high. Consider reducing energy consumption, using public transportation, and recycling more.\n");
        } else if (userFootprintScore > 15) {
            recommendations.add("Your ecological footprint is moderate. Try to use more renewable energy sources and reduce food waste.\n");
        } else if (userFootprintScore > 1) {
            recommendations.add("Your ecological footprint is relatively low. Keep up the good work!");
        } else {
            recommendations.add("You need to answer the questions in order to get recommendations. Unfortunately, no one is able to have a carbon footprint of 0 due to government services one uses.");
        }

        // checks specific user data for additional personalized recommendations
        if (user.getElectricBill() > 25) {
           recommendations.add("Switch to LED lights if you haven't already as they are more energy efficient. \nAlso do big loads of laundry less frequently then smaller loads more frequently.\nLower the room temperature and remember to lower the thermostat overnight or when you're away from home.\n"); 
        } else if (user.getElectricBill() > 75) {
            recommendations.add("Choose ENERGY STAR-certified appliances as they are more efficient which reduces the amount of electricity needed. Also use \nenergy-efficient lighting and only turn on the lights when you need to.\n");
        } else if (user.getElectricBill() > 150) {
            recommendations.add("Choose ENERGY STAR-certified appliances as they are more efficient which reduces the amount of electricity needed. Also use \nenergy-efficient lighting and only turn on the lights when you need to.\n Also avoid phantom electricty by ensuring that desktops and tvs are unplugged instead of shut down if your not planning on using them for a long period of time.\n Finally, use sleep mode on devices instead of screen savers as screen savers do not reduce energy consumption.\n");
        }
        
        if (user.getGasBill() > 25){
            recommendations.add("To reduce your monthly gas bill consider cleaning or changing your furnace filter regularly. \nKeeping air vents and baseboards dust free and unobstructed by carpets or furniture.\n");
        } else if (user.getGasBill() > 75) {
            recommendations.add("During cold weather rely less on your AC and raise your blinds and keeping currents open during the day to take advantage of the sun’s heat. \nOn hot days lower your blinds and close curtains to keep the\ncold in.\n");
        } else if (user.getGasBill() > 150){
            recommendations.add("To lower your monthly gas bill and carbon footprint, keep your fireplace damper closed to prevent heat from escaping through the chimney, chaulk and weatherstrips around windos and doors to eliminate drafts.\nEven consider adding insulation to your walls to improve efficiency and installing energy-efficient windos to stop heat loss.\n");
        }
       
        if (user.getOilBill() > 25){
            recommendations.add("To reduce your monthly oil bill, consider switching to electric lawn mowers and leaf blowers if you don't have them already.\n");
        } else if (user.getOilBill() > 75) {
            recommendations.add("To reduce your monthly oil bill, heat your house to only 20 C in the winter and 26 C in the summer.\n");
        } else if (user.getOilBill() > 150){
            recommendations.add("To reduce your monthly oil bill, heat your house to only 20 C in the winter and 26 C in the summer.\nAlso consider swapping to electric lawnmowers and leafblowers if you cut your lawn often and don't already have these electric products.\n");
        }
        
        if (user.getSmallFlights() > 2) {
            recommendations.add("Instead of flying on a plane to locations that take less than 2 hours, consider taking a train or taking a car for a road trip as that is not \nonly cheaper for you but also better for the environment and gives the ability to make the journey to the location memorable.\n");
        }

        if (user.getYearlyMileage() >= 15000) {
            recommendations.add("To reduce your yearly mileage, consider more sustainable transport options such as walking, biking or public transportation.\n");
        }
        
        if (user.isAluminumTin() == false){
            recommendations.add("To reduce your global footprint you should recycle or reuse aluminium and tin.\n");
        }
        
        if (user.isNewspaper() == false)
            recommendations.add("To reduce your global footprint you should recycle or reuse newspapers.\n");

        // returns the list of recommendations
        return recommendations;
    }

}