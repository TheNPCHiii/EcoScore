/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ecoscore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author Leonard Abou-Assaleh
 */

public class Goals {
    
    // initialises variables for the class
    private String attribute;
    private double reduction, val, reducedVal, currentVal;
    private Users user;
    
    // setter and getter methods
    public Goals(Users user) {
        this.user = user;
    }
    
    public String getAttribute() {
        return attribute;
    }

    public double getVal() {
        return val;
    }

    public double getCurrentVal() {
        return currentVal;
    }

    public double getReducedVal() {
        return reducedVal;
    }
    
    // custom method to clear all goals
    public void clearAllGoals() {
        user.getGoals().clear();
    }
    
    // calculates the reduction in the users carbon footprint if the goal is compleated.
    // calculates the new carbon footprint if the goal is compleated.
    public double getReduction() {
        
        // defines local variables.
        double tempCalc = user.getCO2Eq();
        currentVal = tempCalc;
        double temp;
        boolean placeholder;
        
        // checks what is being changed and then calculates values for reduction and reducedVal by using a switch statement
        switch(attribute){
            case "electric":
                temp = user.getElectricBill();
                user.setElectricBill(val);
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setElectricBill(temp);
                System.out.println("temp: "+temp+", reducedVal: "+reducedVal+", tempCalc: "+tempCalc+", val: "+val);
                break;
            case "gas":
                temp = user.getGasBill();
                user.setGasBill(val);
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setGasBill(temp);
                break;
            case "oil":
                temp = user.getOilBill();
                user.setOilBill(val);
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setOilBill(temp);
                break;
            case "mileage":
                temp = user.getYearlyMileage();
                user.setYearlyMileage(val);
//                System.out.println(user.getCO2Eq());
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setYearlyMileage(temp);
                break;
            case "smallFlights":
                temp = user.getSmallFlights();
                user.setSmallFlights((int) (val));
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setSmallFlights((int) temp);
                break;
            case "largeFlights":
                temp = user.getLargeFlights();
                user.setLargeFlights((int) (val));
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setLargeFlights((int) temp);
                break;
            case "recycle newspaper":
                placeholder = user.isNewspaper();
                if(val == 1){
                    user.setNewspaper(true);
                } else {
                    user.setNewspaper(false);
                }
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setNewspaper(placeholder);
                break;
            case "recycle aluminum and tin":
                placeholder = user.isAluminumTin();
                if(val == 1){
                    user.setAluminumTin(true);
                } else {
                    user.setAluminumTin(false);
                }
                reducedVal = user.getCO2Eq();
                reduction = tempCalc - user.getCO2Eq();
                user.setAluminumTin(placeholder);
                break;
        }
        
        // rounds to 2 decimal places and returns reduction
        reduction = Math.round(reduction*100.0)/100.0;
        return reduction;
    }

    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }

    public void setVal(double val) {
        this.val = val;
    }

    public void setReduction(double reduction) {
        this.reduction = reduction;
    }

    public void setUser(Users user) {
        this.user = user;
    }

    public void setReducedVal(double reducedVal) {
        this.reducedVal = reducedVal;
    }

    public void setCurrentVal(double currentVal) {
        this.currentVal = currentVal;
    }

    // Override toString method.
    @Override
    public String toString() {
        getReduction(); 
        return "Category: " + attribute.toUpperCase() + "\n\tChange in Value: " + val + "\n\tReduction in Carbon Footprint: " + reduction + "\n\tOld Carbon Footprint: " + currentVal + "\n\tNew Carbon Footprint: " + reducedVal; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }
}
